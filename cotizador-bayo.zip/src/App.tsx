import React, { useEffect, useMemo, useState } from 'react';
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer } from 'recharts';

type Item = {
  articulo: string;
  familia: string;
  marca: string;
  pesoKg: number;
  udsCaja: number;
  tarifaG: number;
  precioCaja?: number;
  precioKg?: number;
  objetivoMargen?: number;
  costeCompraCaja?: number;
};

const LS_KEY = "catalogo_bayo_refs_v4";
const SEED_URL = "/catalogo_bayo_seed.json";

export default function App(){
  const [refs, setRefs] = useState<Item[]>([]);
  const [selRef, setSelRef] = useState<Item | null>(null);
  const [query, setQuery] = useState('');

  const [cajas, setCajas] = useState(1);
  const [precioSimCaja, setPrecioSimCaja] = useState(0);
  const [rappelPct, setRappelPct] = useState(0);
  const [costeLogisticoCaja, setCosteLogisticoCaja] = useState(0.66);
  const [costeCompraCaja, setCosteCompraCaja] = useState(0);
  const [objetivoMargen, setObjetivoMargen] = useState(0);

  useEffect(() => {
    (async () => {
      let done = false;
      try {
        const raw = localStorage.getItem(LS_KEY);
        if (raw) {
          const parsed = JSON.parse(raw);
          if (Array.isArray(parsed) && parsed.length) {
            setRefs(parsed);
            setSelRef(parsed[0]);
            setQuery(parsed[0].articulo || '');
            done = true;
          }
        }
      } catch {}

      if (!done) {
        try {
          const res = await fetch(SEED_URL, { cache: 'no-store' });
          if (res.ok) {
            const seed = await res.json();
            if (Array.isArray(seed) && seed.length) {
              const normalized = seed.map((r: Item) => {
                const peso = Number(r.pesoKg||0);
                const uds = Number(r.udsCaja||0);
                const g = Number(r.tarifaG||0);
                const precioCaja = g * uds;
                const precioKg = peso>0 ? g/peso : 0;
                return { ...r, precioCaja, precioKg };
              });
              localStorage.setItem(LS_KEY, JSON.stringify(normalized));
              setRefs(normalized);
              setSelRef(normalized[0]);
              setQuery(normalized[0].articulo || '');
              done = true;
            }
          }
        } catch {}
      }

      if (!done) {
        const fallback: Item[] = [{
          articulo: "ARROZ INTEGRAL BAYO - 1 KG X 12 - 10000082",
          familia: "Integral",
          marca: "Bayo",
          pesoKg: 1,
          udsCaja: 12,
          tarifaG: 1.685,
          precioCaja: 1.685*12,
          precioKg: 1.685,
          objetivoMargen: 10,
          costeCompraCaja: 14.5
        }];
        localStorage.setItem(LS_KEY, JSON.stringify(fallback));
        setRefs(fallback);
        setSelRef(fallback[0]);
        setQuery(fallback[0].articulo);
      }
    })();
  }, []);

  useEffect(() => {
    if (!selRef) return;
    const uds = Number(selRef?.udsCaja||0);
    const g = Number(selRef?.tarifaG||0);
    const precioCaja = g * uds;
    setPrecioSimCaja(precioCaja);
    setCosteCompraCaja(Number(selRef?.costeCompraCaja||0));
    const om = getObjetivoMargen(selRef);
    setObjetivoMargen(om);
  }, [selRef]);

  const pesoUd = Number(selRef?.pesoKg||0);
  const udsCaja = Number(selRef?.udsCaja||0);
  const kgCaja = pesoUd * udsCaja;

  const precioTarifaCaja = useMemo(() => {
    const g = Number(selRef?.tarifaG||0);
    return g * udsCaja;
  }, [selRef, udsCaja]);

  const precioTarifaKg = useMemo(() => {
    const g = Number(selRef?.tarifaG||0);
    const peso = Number(selRef?.pesoKg||0);
    return peso>0 ? g/peso : 0;
  }, [selRef]);

  const precioSimKg = useMemo(() => (kgCaja ? precioSimCaja / kgCaja : 0), [precioSimCaja, kgCaja]);
  const ventaNeta = useMemo(() => precioSimCaja * cajas, [precioSimCaja, cajas]);
  const dtoPct = useMemo(() => (!precioTarifaCaja ? 0 : (1 - precioSimCaja / precioTarifaCaja) * 100), [precioSimCaja, precioTarifaCaja]);
  const costeRappelCaja = useMemo(() => (precioSimCaja * (rappelPct || 0)) / 100, [precioSimCaja, rappelPct]);
  const margenBrutoPct = useMemo(() => (precioSimCaja <= 0 ? 0 : ((precioSimCaja - costeCompraCaja) / precioSimCaja) * 100), [precioSimCaja, costeCompraCaja]);
  const margenContribucionPct = useMemo(() => {
    if (precioSimCaja <= 0) return 0;
    const contrib = precioSimCaja - costeCompraCaja - costeLogisticoCaja - costeRappelCaja;
    return (contrib / precioSimCaja) * 100;
  }, [precioSimCaja, costeCompraCaja, costeLogisticoCaja, costeRappelCaja]);

  const alertaNegativa = margenContribucionPct < 0;
  const atencionMargen = !alertaNegativa && margenContribucionPct < (objetivoMargen || 0);

  const sugerencias = useMemo(() => {
    const q = (query || '').toLowerCase();
    return (refs || []).filter(r => (r.articulo || '').toLowerCase().includes(q)).slice(0, 20);
  }, [query, refs]);

  function getObjetivoMargen(item:any){
    const v = item?.objetivoMargen ?? item?.["Objetivo Margen"] ?? item?.["MARGEN BDGT 2425"] ?? item?.S ?? 0;
    const n = Number(String(v).replace(',','.'));
    return isFinite(n) ? n : 0;
  }

  function onImport(items: any[]) {
    setRefs(items);
    if (items.length) {
      setSelRef(items[0]);
      setQuery(items[0].articulo || '');
    }
    localStorage.setItem(LS_KEY, JSON.stringify(items));
  }

  const Stat = ({k, v, fmt='pct'}: {k:string; v:number; fmt?:'pct'|'eur'}) => {
    const val = fmt === 'pct' ? `${v.toFixed(2)}%` : `${v.toFixed(2)}€`;
    return <div className="kpi"><div className="k">{k}</div><div className="v">{val}</div></div>;
  };

  return (
    <div className="container">
      <div className="flex wrap" style={{justifyContent:'space-between', alignItems:'center'}}>
        <h1 className="title">Cotizador HORECA – Arroz Bayo</h1>
        <div className="flex wrap" style={{alignItems:'center'}}>
          <Importador onLoad={onImport} />
          <button className="btn" onClick={()=>{
            localStorage.setItem(LS_KEY, JSON.stringify(refs));
            alert('Catálogo guardado en este dispositivo.');
          }}>Guardar</button>
          <span className="muted">{refs?.length ? `${refs.length} referencias` : ''}</span>
        </div>
      </div>

      {!selRef ? (
        <div className="card">
          <p>Sin catálogo cargado. Usa <b>Importar JSON/Excel</b> o añade el archivo <code>public/catalogo_bayo_seed.json</code> y recarga.</p>
          <p>Columnas esperadas: <code>ARTICULO, FAMILIA, MARCA, PESO KG, UD CAJA, Precio unidad, Objetivo Margen</code>.</p>
        </div>
      ):(<>
        <div className="card">
          <div className="grid grid-3">
            <div>
              <label>Referencia</label>
              <input list="referencias" value={query} onChange={(e)=>{
                const v = e.target.value;
                setQuery(v);
                const exact = (refs || []).find(r => r.articulo === v);
                if (exact) setSelRef(exact);
              }} placeholder="ARROZ VAPORIZADO LARGO BAYO 5 KG X 4 - 10000131" />
              <datalist id="referencias">
                {(sugerencias || []).map((r:any, i:number) => (
                  <option key={i} value={r.articulo} />
                ))}
              </datalist>
              <p className="muted">Familia: <b>{selRef.familia}</b> • Marca: <b>{selRef.marca}</b></p>
              <p className="muted">Peso ud: <b>{pesoUd} kg</b> • Ud/Caja: <b>{udsCaja}</b> • Kg/Caja: <b>{kgCaja}</b></p>
              <p className="muted">Precio caja: <b>{precioTarifaCaja.toFixed(3)}€</b> • Precio/kg: <b>{precioTarifaKg.toFixed(3)}€</b></p>
            </div>

            <div>
              <label>Coste logístico por caja (€)</label>
              <input type="number" step="0.01" inputMode="decimal" value={costeLogisticoCaja} onChange={(e)=> setCosteLogisticoCaja(parseFloat(e.target.value || '0'))} />
              <label>Coste de compra por caja (€)</label>
              <input type="number" step="0.01" inputMode="decimal" value={costeCompraCaja} onChange={(e)=> setCosteCompraCaja(parseFloat(e.target.value || '0'))} />
              <label>Objetivo Margen (%)</label>
              <div className="flex" style={{alignItems:'center', gap:8}}>
                <input type="number" step="0.1" inputMode="decimal" value={objetivoMargen} onChange={(e)=> setObjetivoMargen(parseFloat(e.target.value || '0'))} />
                <span className={`badge ${margenContribucionPct >= (objetivoMargen||0) ? 'ok' : 'bad'}`}>
                  {margenContribucionPct >= (objetivoMargen||0) ? '≥ objetivo' : '< objetivo'}
                </span>
              </div>
            </div>

            <div>
              <p style={{fontSize:13, fontWeight:600}}>Desglose por caja</p>
              <div style={{height:220}}>
                <ResponsiveContainer>
                  <PieChart>
                    <Pie dataKey="value" data={[
                      { name: 'Compra', value: costeCompraCaja },
                      { name: 'Logística', value: costeLogisticoCaja },
                      { name: 'Rappel', value: (precioSimCaja * (rappelPct || 0)) / 100 },
                      { name: 'Beneficio', value: Math.max(precioSimCaja - (costeCompraCaja + costeLogisticoCaja + (precioSimCaja * (rappelPct || 0)) / 100), 0) }
                    ]} outerRadius={90}>
                      <Cell />
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <ul className="muted">
                <li>Compra: {costeCompraCaja.toFixed(2)}€</li>
                <li>Logística: {costeLogisticoCaja.toFixed(2)}€</li>
                <li>Rappel: {((precioSimCaja * (rappelPct || 0)) / 100).toFixed(2)}€</li>
                <li>Beneficio: {(precioSimCaja - (costeCompraCaja + costeLogisticoCaja + (precioSimCaja * (rappelPct || 0)) / 100)).toFixed(2)}€</li>
              </ul>
            </div>
          </div>
        </div>

        <div className="card">
          <div className="grid grid-3">
            <div>
              <label>Precio caja (tarifa) (€)</label>
              <input readOnly value={precioTarifaCaja.toFixed(3)} />
              <label>Precio caja simulado (€)</label>
              <input type="number" step="0.01" inputMode="decimal" value={precioSimCaja} onChange={(e)=> setPrecioSimCaja(parseFloat(e.target.value || '0'))} />
              <label>Precio Kg simulado (€)</label>
              <input readOnly value={precioSimKg.toFixed(3)} />
              <label>Total cajas</label>
              <input type="number" step="1" inputMode="numeric" value={cajas} onChange={(e)=> setCajas(parseInt(e.target.value || '0', 10))} />
              <label>% Rappel</label>
              <input type="number" step="0.01" inputMode="decimal" value={rappelPct} onChange={(e)=> setRappelPct(parseFloat(e.target.value || '0'))} />
            </div>
            <div>
              <div className="space">
                <div className="muted" style={{textTransform:'uppercase'}}>Venta neta</div>
                <div style={{fontSize:24, fontWeight:600}}>{ventaNeta.toFixed(2)}€</div>
              </div>
              <div className="grid" style={{gridTemplateColumns:'1fr 1fr 1fr'}}>
                <Stat k="%DTO" v={dtoPct} fmt="pct" />
                <Stat k="%MB" v={margenBrutoPct} fmt="pct" />
                <Stat k="%MC" v={margenContribucionPct} fmt="pct" />
              </div>
              {margenContribucionPct < 0 && (
                <div className="alert bad">⚠️ <b>Alerta:</b> el margen es <b>negativo</b> con los parámetros actuales.</div>
              )}
              {! (margenContribucionPct < 0) && (margenContribucionPct < (objetivoMargen||0)) && (
                <div className="alert warn">ℹ️ <b>Atención:</b> el margen está por debajo del <b>Objetivo Margen</b>.</div>
              )}
            </div>
            <div>
              <button className="btn primary" onClick={()=> window.print()}>Imprimir / PDF</button>
              <button className="btn" onClick={()=> navigator.clipboard.writeText(JSON.stringify({
                articulo: selRef?.articulo,
                familia: selRef?.familia,
                marca: selRef?.marca,
                pesoKg: selRef?.pesoKg,
                udsCaja: selRef?.udsCaja,
                kgCaja,
                tarifaG: selRef?.tarifaG,
                cajas,
                precioTarifaCaja,
                precioTarifaKg,
                precioSimCaja,
                precioSimKg,
                rappelPct,
                ventaNeta,
                dtoPct,
                margenBrutoPct,
                margenContribucionPct,
                objetivoMargen,
              }, null, 2))}>Copiar resumen</button>
            </div>
          </div>
        </div>
      </>)}

      <div className="card">
        <p style={{fontSize:13, fontWeight:600}}>Pruebas rápidas</p>
        <ul className="muted">
          {runTests().map((t,i)=> <li key={i} style={{color: t.ok?'#065f46':'#991b1b'}}>{t.ok?'✔':'✖'} {t.name}{t.ok?'':` → ${t.msg}`}</li>)}
        </ul>
      </div>

      <div className="footer">Columna G = precio por unidad; Precio caja = G×UD, Precio/kg = G÷PESO. Los datos quedan guardados en este dispositivo.</div>
    </div>
  );
}

function Importador({ onLoad }: { onLoad: (items: any[]) => void }){
  const [err, setErr] = useState<string|null>(null);
  const [loading, setLoading] = useState(false);

  async function parseFile(file: File){
    setErr(null); setLoading(true);
    try {
      if (file.name.endsWith('.json')) {
        const text = await file.text();
        const arr = JSON.parse(text);
        onLoad(normaliza(arr));
      } else if (file.name.endsWith('.csv')) {
        const text = await file.text();
        const rows = csvToJson(text);
        onLoad(normaliza(rows));
      } else if (file.name.endsWith('.xlsx') || file.name.endsWith('.xls')) {
        const XLSX = await import('xlsx');
        const buf = await file.arrayBuffer();
        const wb = XLSX.read(buf);
        const ws = wb.Sheets[wb.SheetNames[0]];
        const rows = XLSX.utils.sheet_to_json(ws, { defval: null, raw: false });
        onLoad(normaliza(rows));
      } else {
        throw new Error('Formato no soportado');
      }
    } catch(e:any){
      setErr(e.message || 'Error al importar');
    } finally {
      setLoading(false);
    }
  }

  function normaliza(rows:any[]): any[]{
    return (rows||[]).map((r:any)=>{
      const peso = num(r['PESO KG'] ?? r['pesoKg'] ?? 0);
      const uds  = num(r['UD CAJA'] ?? r['udsCaja'] ?? 0);
      const g    = num(r['TARIFA DIC 24'] ?? r['G'] ?? r['tarifaG'] ?? 0);
      const precioCaja = g * uds;
      const precioKg = peso>0 ? g/peso : 0;
      return {
        articulo: r['ARTICULO'] ?? r['articulo'] ?? '',
        familia: r['FAMILIA'] ?? r['familia'] ?? '',
        marca: r['MARCA'] ?? r['marca'] ?? '',
        pesoKg: peso,
        udsCaja: uds,
        tarifaG: g,
        precioCaja,
        precioKg,
        objetivoMargen: num(r['Objetivo Margen'] ?? r['MARGEN BDGT 2425'] ?? r['S'] ?? r['objetivoMargen'] ?? 0),
        costeCompraCaja: num(r['costeCompraCaja'] ?? r['Coste Compra Caja'] ?? 0)
      };
    }).filter((x:any)=> x.articulo);
  }

  function num(v:any){ if(v===null||v===undefined) return 0; const n = Number(String(v).replace(',','.')); return isFinite(n)? n : 0; }

  function csvToJson(text:string){
    const lines = text.split(/\r?\n/).filter(Boolean);
    if (!lines.length) return [] as any[];
    const cols = lines[0].split(',').map(s=>s.trim());
    return lines.slice(1).map(line => {
      const vals = line.split(',');
      const obj:any = {};
      cols.forEach((c,i)=> obj[c] = vals[i]);
      return obj;
    });
  }

  return (
    <label className="flex" style={{alignItems:'center', gap:8, cursor:'pointer'}}>
      <input type="file" accept=".json,.csv,.xlsx,.xls" style={{display:'none'}} onChange={(e)=>{ const f=e.target.files?.[0]; if(f) parseFile(f); }}/>
      <button className="btn" disabled={loading}>{loading? 'Importando…':'Importar JSON/Excel'}</button>
      {err && <span style={{color:'#b91c1c', fontSize:12}}>{err}</span>}
    </label>
  );
}

function runTests(){
  const tests: {name:string; ok:boolean; msg?:string}[] = [];
  try {
    const peso = 5, uds = 4, G = 9.212;
    const precioCaja = G * uds; // 36.848
    const precioKg = G / peso;  // 1.8424
    tests.push({ name: "Ejemplo 10000131 caja desde G (unidad)", ok: Math.abs(precioCaja - 36.848) < 1e-6 });
    tests.push({ name: "Ejemplo 10000131 kg desde G (unidad)", ok: Math.abs(precioKg - 1.8424) < 1e-6 });
  } catch(e:any){ tests.push({ name: "Ejemplo 10000131", ok:false, msg:e.message }); }

  try {
    const peso = 1, uds = 12, G = 1.685;
    const precioCaja = G * uds; // 20.22
    const precioKg = G / peso;  // 1.685
    tests.push({ name: "Caso 1kg x 12", ok: Math.abs(precioCaja - 20.22) < 1e-6 && Math.abs(precioKg - 1.685) < 1e-6 });
  } catch(e:any){ tests.push({ name: "Caso 1kg x 12", ok:false, msg:e.message }); }

  try {
    const tarifaCaja = 20, simCaja = 18;
    const dto = (1 - simCaja/tarifaCaja) * 100;
    tests.push({ name: "%DTO correcto", ok: Math.abs(dto - 10) < 1e-6 });
  } catch(e:any){ tests.push({ name: "%DTO", ok:false, msg:e.message }); }

  try {
    const precio = 20, compra = 19, log = 1.5, rapp = 0.5;
    const mc = ((precio - compra - log - rapp)/precio)*100;
    const alertaNeg = mc < 0;
    const atencion = !alertaNeg && mc < 10;
    tests.push({ name: "Alerta margen negativo", ok: alertaNeg === true });
    tests.push({ name: "Atención < objetivo", ok: atencion === false });
  } catch(e:any){ tests.push({ name: "Alertas", ok:false, msg:e.message }); }

  try {
    const csvWin = "A,B\r\n1,2\r\n3,4\r\n";
    const csvUnix = "A,B\n1,2\n3,4\n";
    const parse = (text:string) => {
      const lines = text.split(/\r?\n/).filter(Boolean);
      const cols = lines[0].split(',');
      const rows = lines.slice(1).map(l=>{
        const vals = l.split(','); const o:any = {}; cols.forEach((c,i)=>o[c]=vals[i]); return o;
      });
      return {cols, rows};
    };
    const w = parse(csvWin); const u = parse(csvUnix);
    tests.push({ name: "CSV Windows líneas", ok: w.rows.length === 2 && w.rows[0]['A'] === '1' && w.rows[1]['B'] === '4' });
    tests.push({ name: "CSV Unix líneas", ok: u.rows.length === 2 && u.rows[0]['A'] === '1' && u.rows[1]['B'] === '4' });
  } catch(e:any){ tests.push({ name: "CSV parser", ok:false, msg:e.message }); }

  return tests;
}
